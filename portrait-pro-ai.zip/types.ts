
export enum AppStatus {
  Idle = 'idle',
  Loading = 'loading',
  Result = 'result',
  Error = 'error',
}
