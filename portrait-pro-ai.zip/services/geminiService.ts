
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  // In a real app, you'd handle this more gracefully.
  // For this environment, we assume the key is present.
  console.warn("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const model = 'gemini-2.5-flash-image';

const generationPrompt = `
You are an expert image editing assistant. Your task is to transform a user-uploaded selfie into a high-quality, professional portrait suitable for a CV or professional profile. Follow these rules meticulously:

1.  **Analyze the Image:**
    *   Detect the single face in the provided image.
    *   Determine if the person is male or female. This is crucial for the next step.
    *   Preserve the person's identity, age, race, and unique facial features. Do not alter them.

2.  **Perform Core Edits (Apply to all images):**
    *   **Background:** Completely remove the original background and replace it with a clean, professional, solid light-gray background (#f1f5f9).
    *   **Pose & Framing:** If the head is tilted, straighten it to be upright. Center the person so the final image is a standard head-and-shoulders portrait. Do not distort the face.
    *   **Lighting & Quality:** Enhance the lighting to be bright and clear. Improve contrast and sharpness. If the source image is low-resolution or blurry, upscale it to a high-resolution, professional quality. Keep the natural skin tone.

3.  **Apply Outfit Logic based on Gender:**

    *   **IF MALE:**
        *   Replace the original clothing with a single, classic, professional business suit. This should include a dark navy or charcoal gray suit jacket, a crisp white dress shirt, and a subtle tie.
        *   Generate **ONLY ONE** final image.

    *   **IF FEMALE:**
        *   Replace the original clothing with professional, modest business attire.
        *   Generate **EXACTLY 4 DIFFERENT OUTFIT OPTIONS** for the user to choose from. The options should be distinct:
            1.  A dark navy blazer over a white silk blouse.
            2.  A light gray or beige blazer over a neutral-colored top.
            3.  An elegant, simple business dress with sleeves in a charcoal gray color.
            4.  A professional collared blouse in a soft, solid color like light blue or off-white.
        *   Ensure the outfits look natural, fit well, and are distinctly feminine in style.

4.  **Final Output Rules:**
    *   The final image(s) must be photorealistic, high-resolution, and sharp.
    *   Do not add any text, watermarks, or filters.
    *   If the input image is completely unusable (e.g., no clear face), return only the text: "ERROR: Face not clear enough. Please upload a clearer photo with your full face visible."
`;


export async function createProfessionalPortrait(base64Image: string, mimeType: string): Promise<string[]> {
  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          { inlineData: { data: base64Image, mimeType: mimeType } },
          { text: generationPrompt },
        ],
      },
    });

    const portraits: string[] = [];
    let errorMessage = "";

    if (response.candidates && response.candidates.length > 0) {
        const candidate = response.candidates[0];
        if (candidate.content && candidate.content.parts) {
            for (const part of candidate.content.parts) {
                if (part.inlineData) {
                    portraits.push(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
                } else if (part.text && part.text.includes('ERROR:')) {
                    errorMessage = part.text.replace('ERROR: ', '');
                }
            }
        }
    }
    
    if (errorMessage) {
        throw new Error(errorMessage);
    }
    
    if (portraits.length === 0 && !errorMessage) {
      // Check for a general text response if no images and no specific error
      const textResponse = response.text;
      if (textResponse) {
          throw new Error(`The AI responded with text instead of an image: "${textResponse}"`);
      }
      throw new Error("The AI model did not return any images.");
    }

    return portraits;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to generate portrait: ${error.message}`);
    }
    throw new Error("An unknown error occurred while communicating with the AI.");
  }
}
