
import React, { useState, useEffect } from 'react';

const loadingSteps = [
  "Analyzing your photo...",
  "Removing the background...",
  "Correcting pose and lighting...",
  "Enhancing image quality...",
  "Generating professional outfits...",
  "Almost there, finalizing your portrait..."
];

interface LoadingIndicatorProps {
    originalImage: string | null;
}

const LoadingIndicator: React.FC<LoadingIndicatorProps> = ({ originalImage }) => {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep(prev => (prev + 1) % loadingSteps.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full h-full flex flex-col items-center justify-center text-center p-8 animate-fade-in">
      <div className="relative w-48 h-48 sm:w-64 sm:h-64 mb-8">
        {originalImage && (
            <img 
                src={originalImage}
                alt="Uploaded selfie"
                className="w-full h-full object-cover rounded-full shadow-2xl filter blur-sm"
            />
        )}
        <div className="absolute inset-0 rounded-full bg-slate-900 bg-opacity-50 flex items-center justify-center">
            <div className="w-20 h-20 border-4 border-t-teal-400 border-slate-200 rounded-full animate-spin"></div>
        </div>
      </div>
      <h2 className="text-2xl font-bold text-slate-800 mb-4">Crafting Your Portrait</h2>
      <p className="text-slate-600 text-lg transition-opacity duration-500">
        {loadingSteps[currentStep]}
      </p>
    </div>
  );
};

export default LoadingIndicator;
