
import React, { useState, useCallback, useRef } from 'react';
import { UploadIcon } from './icons/UploadIcon';

interface ImageUploaderProps {
  onImageUpload: (file: File) => void;
  error: string | null;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, error }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onImageUpload(e.target.files[0]);
    }
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDragIn = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setIsDragging(true);
    }
  }, []);

  const handleDragOut = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);
  
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onImageUpload(e.dataTransfer.files[0]);
      e.dataTransfer.clearData();
    }
  }, [onImageUpload]);

  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col items-center justify-center p-8 animate-fade-in">
      <div
        onDragEnter={handleDragIn}
        onDragLeave={handleDragOut}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`w-full p-10 border-2 border-dashed rounded-2xl transition-all duration-300 text-center flex flex-col items-center justify-center
        ${isDragging ? 'border-teal-500 bg-teal-50' : 'border-slate-300 bg-white'}`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png, image/jpeg, image/webp"
          onChange={handleFileChange}
          className="hidden"
        />
        <div className="p-4 bg-teal-100 rounded-full mb-6">
           <UploadIcon className="w-8 h-8 text-teal-600" />
        </div>
        <h2 className="text-xl font-semibold text-slate-700 mb-2">Upload Your Selfie</h2>
        <p className="text-slate-500 mb-6">Drag & drop a file or click to select</p>
        <button
          onClick={onButtonClick}
          className="px-6 py-3 bg-teal-500 text-white font-semibold rounded-lg shadow-md hover:bg-teal-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-transform transform hover:scale-105"
        >
          Choose File
        </button>
      </div>
      {error && (
        <div className="mt-6 w-full p-4 bg-red-100 border border-red-200 text-red-700 rounded-lg text-center animate-fade-in">
          <p className="font-semibold">Oh no! Something went wrong.</p>
          <p>{error}</p>
        </div>
      )}
      <div className="mt-8 text-center text-slate-600 max-w-lg">
        <h3 className="text-lg font-semibold mb-2">Instructions</h3>
        <ul className="text-sm list-disc list-inside text-left space-y-1">
            <li>Upload a clear, front-facing photo of yourself.</li>
            <li>Ensure good lighting for best results.</li>
            <li>Our AI will generate a professional portrait for you.</li>
        </ul>
      </div>
    </div>
  );
};

export default ImageUploader;
