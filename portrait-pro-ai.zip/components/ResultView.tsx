
import React, { useState, useEffect } from 'react';
import { DownloadIcon } from './icons/DownloadIcon';
import { ResetIcon } from './icons/ResetIcon';

interface ResultViewProps {
  originalImage: string;
  generatedPortraits: string[];
  onReset: () => void;
}

const ResultView: React.FC<ResultViewProps> = ({ originalImage, generatedPortraits, onReset }) => {
  const [selectedPortrait, setSelectedPortrait] = useState<string>('');

  useEffect(() => {
    if (generatedPortraits.length > 0) {
      setSelectedPortrait(generatedPortraits[0]);
    }
  }, [generatedPortraits]);

  const isMultiOption = generatedPortraits.length > 1;

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = selectedPortrait;
    link.download = 'professional-portrait.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="w-full flex flex-col lg:flex-row gap-8 animate-fade-in">
      {/* Main Display and Controls */}
      <div className="flex-grow flex flex-col items-center lg:w-3/5">
        <div className="w-full max-w-2xl bg-white rounded-2xl shadow-xl overflow-hidden p-6 animate-slide-up">
          <div className="relative aspect-[3/4] w-full">
            {selectedPortrait ? (
              <img
                key={selectedPortrait}
                src={selectedPortrait}
                alt="Generated Professional Portrait"
                className="w-full h-full object-cover rounded-xl transition-all duration-500 animate-fade-in"
              />
            ) : (
               <div className="w-full h-full bg-slate-200 rounded-xl animate-pulse"></div>
            )}
          </div>
          <div className="mt-6 flex flex-col sm:flex-row gap-4">
            <button
              onClick={handleDownload}
              disabled={!selectedPortrait}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-teal-500 text-white font-semibold rounded-lg shadow-md hover:bg-teal-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-all transform hover:scale-105 disabled:bg-slate-400 disabled:cursor-not-allowed"
            >
              <DownloadIcon className="w-5 h-5" />
              Download Portrait
            </button>
            <button
              onClick={onReset}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 text-slate-700 font-semibold rounded-lg hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-400 transition-all"
            >
              <ResetIcon className="w-5 h-5" />
              Start Over
            </button>
          </div>
        </div>
      </div>

      {/* Options Selector */}
      <div className="lg:w-2/5 flex flex-col items-center">
        <div className="w-full max-w-2xl bg-white rounded-2xl shadow-xl p-6 animate-slide-up" style={{animationDelay: '0.1s'}}>
          <h2 className="text-xl font-bold text-slate-800 mb-1">
            {isMultiOption ? 'Choose Your Outfit' : 'Your Professional Portrait'}
          </h2>
          <p className="text-slate-500 mb-4">
            {isMultiOption ? 'Select your favorite look below.' : 'Your new headshot is ready!'}
          </p>

          <div className="grid grid-cols-2 gap-4">
             {generatedPortraits.map((portrait, index) => (
                <div
                    key={index}
                    onClick={() => setSelectedPortrait(portrait)}
                    className={`relative aspect-[3/4] rounded-lg overflow-hidden cursor-pointer transition-all duration-300 transform hover:scale-105
                    ${selectedPortrait === portrait ? 'ring-4 ring-teal-500 shadow-lg' : 'ring-2 ring-transparent'}`}
                >
                    <img src={portrait} alt={`Outfit option ${index + 1}`} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black bg-opacity-20 hover:bg-opacity-0 transition-opacity"></div>
                </div>
             ))}
          </div>
           <div className="mt-6">
                <h3 className="text-lg font-bold text-slate-800 mb-2">Original Photo</h3>
                <img src={originalImage} alt="Original selfie" className="w-full aspect-[3/4] object-cover rounded-lg" />
           </div>
        </div>
      </div>
    </div>
  );
};

export default ResultView;
