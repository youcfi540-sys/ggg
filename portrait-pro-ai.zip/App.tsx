
import React, { useState, useCallback } from 'react';
import { AppStatus } from './types';
import { createProfessionalPortrait } from './services/geminiService';
import { fileToBase64 } from './utils/imageUtils';

import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import LoadingIndicator from './components/LoadingIndicator';
import ResultView from './components/ResultView';

export default function App() {
  const [status, setStatus] = useState<AppStatus>(AppStatus.Idle);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [generatedPortraits, setGeneratedPortraits] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = useCallback(async (file: File) => {
    setStatus(AppStatus.Loading);
    setError(null);
    setGeneratedPortraits([]);

    try {
      const { base64, mimeType } = await fileToBase64(file);
      setOriginalImage(base64);

      const portraits = await createProfessionalPortrait(base64, mimeType);

      if (portraits.length === 0) {
        throw new Error("The AI failed to generate any images. Please try a different photo.");
      }

      setGeneratedPortraits(portraits);
      setStatus(AppStatus.Result);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      console.error(e);
      setError(errorMessage);
      setStatus(AppStatus.Error);
    }
  }, []);

  const handleReset = useCallback(() => {
    setStatus(AppStatus.Idle);
    setOriginalImage(null);
    setGeneratedPortraits([]);
    setError(null);
  }, []);

  const renderContent = () => {
    switch (status) {
      case AppStatus.Idle:
      case AppStatus.Error:
        return (
          <ImageUploader onImageUpload={handleImageUpload} error={error} />
        );
      case AppStatus.Loading:
        return (
          <LoadingIndicator originalImage={originalImage}/>
        );
      case AppStatus.Result:
        return (
          <ResultView
            originalImage={originalImage!}
            generatedPortraits={generatedPortraits}
            onReset={handleReset}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col text-slate-800">
      <Header />
      <main className="flex-grow flex flex-col items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-7xl mx-auto">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}
